
package atm;

import java.util.Date;

/**
 *
 * @author simbongile.mbombo
 */
public class Transaction {
    
    private double amount;
    private Date timestamp;
    private String memo;
   
    
    private Account inAccount;
    
    public Transaction (double amount, Account inAccount){
        this.amount = amount;
        this.timestamp = new Date();
        this.memo = "";
        this.inAccount = inAccount;
        
        
    }

    public Transaction(double amount, Date timestamp, String memo, Account inAccount) {
        
        this(amount, inAccount);
        this.memo = memo;
    }

    Transaction(double amount, String memo, Account aThis) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    
    public double getAmount(){
        
        return this.amount;
    }
    
    public String getSummaryLine(){
        
        if(this.amount >=0){
            return String.format("%s : R%.02f : %s", this.timestamp.toString(), this.amount, this.memo);
        }else{
            return String.format("%s : R(%.02f) : %s", this.timestamp.toString(), this.amount, this.memo);
            
        }
    }
    
   
}
