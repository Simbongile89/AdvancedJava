
package atm;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author simbongile.mbombo
 */
public class Bank {
    
    private String name;
    
    private ArrayList<AccHolder> users;
    
    private ArrayList<Account> accounts;
    
    public Bank(String name){
        this.name=name;
        this.users = new ArrayList<AccHolder>();
        this.accounts = new ArrayList<Account>();
    }
    
    public String getNewUserUUID(){
        
        String uuid;
        Random rng = new Random();
        int len =6;
        boolean nonUnique;
        
        do{
            uuid="";
            for(int i= 0; i<len;i++){
                uuid+= ((Integer)rng.nextInt(10)).toString();
            }
            nonUnique = false;
            for (AccHolder u : this.users){
                
                if(uuid.compareTo(u.getUUID())==0){
                nonUnique= true;
                break;
            }
            }
            
        } while (nonUnique);
        
        return uuid;
        
    }
    
    public String getNewAccountUUID(){
        
              String uuid;
        Random rng = new Random();
        int len =10;
        boolean nonUnique;
        
        do{
            uuid="";
            for(int i= 0; i<len;i++){
                uuid+= ((Integer)rng.nextInt(10)).toString();
            }
            nonUnique = false;
            for (Account u : this.accounts){
                
                if(uuid.compareTo(u.getUUID())==0){
                nonUnique= true;
                break;
            }
            }
            
        } while (nonUnique);
        
        return uuid;
        
    }
    
    
    
    public void addAccount(Account anAcct){
        
        this.accounts.add(anAcct);
    }
    
    public AccHolder addUser(String FirstName, String LastName, String pin){
        
        AccHolder newUser = new AccHolder(FirstName, LastName, pin, this);
        this.users.add(newUser);
        
       Account newAccount = new Account("Savings", newUser, this);
       newUser.addAccount(newAccount);
       this.accounts.add(newAccount);
       
       return newUser;
    }
       
    public AccHolder userLogin(String userID, String pin)  {
             
             for (AccHolder a : this.users){
                 
                 if(a.getUUID().compareTo(userID)== 0 && a.validatePin(pin)){
                     
                     return a;
                 }
             }
             
             return null;
         } 
         
         public String getName(){
             
             return this.name;
         }
}
